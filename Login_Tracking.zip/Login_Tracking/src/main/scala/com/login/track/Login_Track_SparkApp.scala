package com.login.track
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._

import org.apache.spark.sql._
import org.apache.spark.metrics
import java.util.ArrayList
import org.apache.spark.sql.types.IntegerType
import java.util.Properties
import java.io._
import scala.io.Source  

import scala.collection.JavaConversions._
import org.apache.spark.ml.feature.Bucketizer

import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.{array, lit, map, struct}
import java.time.LocalDateTime
import org.apache.spark.sql.functions.expr
import org.apache.spark.sql.functions._
import java.util.UUID
import java.time.format.DateTimeFormatter

import java.text.SimpleDateFormat
import org.apache.spark.sql.expressions._
import org.apache.spark.sql.types.DataType
import org.apache.spark.sql.Row 
 import org.apache.spark.sql.types.StructType
 import org.apache.spark.sql.{Encoder, Encoders}
import org.apache.spark.sql.types.{DataType,AnyDataType}
import org.apache.spark.rdd.RDD
import org.slf4j.Logger
import org.slf4j.LoggerFactory

object Login_Track_SparkApp {
  
 
  def main(args: Array[String])
  {
     
   val logger = LoggerFactory.getLogger("Login_Track_SparkApp")
  
   logger.info("creating spark session")
   
   val spark = org.apache.spark.sql.SparkSession.builder
        .master("local")
        .appName("Spark CSV Reader")
        .getOrCreate;
  
  import spark.implicits._
  
  //define the schema 
  
  val schemaUntyped = new StructType()
  .add("duration", "int")
  .add("protocol_type", "string")
  .add("service","string")
  .add("flag","string")
  .add("src_bytes","int")
  .add("dst_bytes","int")
  .add("land","int") 
  .add("wrong_fragment","int")
  .add("urgent","int")
  .add("hot","string")
  .add("num_failed_logins","int")
  .add("logged_in","int")
  .add("num_compromised","int")
  .add("root_shell","int")
  .add("su_attempted","int")
  .add("num_root","int")
  .add("num_file_creations","int")
  .add("num_shells","int")
  .add("num_access_files","int")
  .add("num_outbound_cmds","int")
  .add("is_host_login","int")
  .add("is_guest_login","int") 
  .add("count","int")
  .add("srv_count","int")
  .add("serror_rate","Double")
  .add("srv_serror_rate","Double")
  .add("rerror_rate","Double")
  .add("srv_rerror_rate","Double")
  .add("same_srv_rate","Double")
  .add("diff_srv_rate","Double")
  .add("srv_diff_host_rate","Double")
  .add("dst_host_count","int")
  .add("dst_host_srv_count","int")
  .add("dst_host_same_srv_rate","Double")
  .add("dst_host_diff_srv_rate","Double")
  .add("dst_host_same_src_port_rate","Double")
  .add("dst_host_srv_diff_host_rate","Double")
  .add("dst_host_serror_rate","Double")
  .add("dst_host_srv_serror_rate","Double")
  .add("dst_host_rerror_rate","Double")
  .add("dst_host_srv_rerror_rate","Double")
  .add("label","string")
  
  
   
  val df = spark.read
         .format("csv")
         .schema(schemaUntyped)
        .load("C:/Users/Ramanjaneyulu.K/Desktop/Ramu/kddcup.data.corrected")
        
      /* Task 2 
         Find the services for which total file creation operations are more than total access file operations where duration is at least half a minute. */

      val windowSpec = Window.partitionBy("service")
      val df1 = df.withColumn("total_file_creation_operation", sum(df.col("num_file_creations")).over(windowSpec))
      val df2 = df1.withColumn("total_file_access_operation", sum(df.col("num_access_files")).over(windowSpec))
      df2.createOrReplaceTempView("Network_Tracking")
   
      val df_task2=spark.sql("select distinct service,total_file_creation_operation,total_file_access_operation from Network_Tracking where duration>=30 and total_file_creation_operation >total_file_access_operation")
      df_task2.write.option("header", "true").csv("C:/Users/Ramanjaneyulu.K/Desktop/Task2")
      
      
    // Task 1 For each protocol_type, find the min, max, average, median, SD of #failed logins, #compromised conditions and #file creation operations . 
  
   
     //calculate the standard deviation
 val df_with_stdev=  df1.groupBy(df1.col("protocol_type")).
     agg(
         min(df1.col("num_failed_logins")).as("min_failed_logins"),
         max(df1.col("num_failed_logins")).as("max_failed_logins"),
         avg(df1.col("num_failed_logins")).as("avg_failed_logins"),
        
         min(df1.col("num_compromised")).as("min_num_compromised"),
         max(df1.col("num_compromised")).as("max_num_compromised"),
         avg(df1.col("num_compromised")).as("avg_num_compromised"),
        
         min(df1.col("num_file_creations")).as("min_num_file_creations"),
         max(df1.col("num_file_creations")).as("max_num_file_creations"),
         avg(df1.col("num_file_creations")).as("avg_num_file_creations"),
        
         stddev_pop (df1.col("num_failed_logins")).alias("num_failed_logins_stdev"),
         stddev_pop(df1.col("num_compromised")).alias("num_compromised_stdev"),
         stddev_pop(df1.col("num_file_creations")).alias("num_file_creations_stdev"),
         
           count(df1.col("num_failed_logins")).as("cnt_num_failed_logins"),
           count(df1.col("num_compromised")).as("cnt_num_compromised"),
           count(df1.col("num_file_creations")).as("cnt_num_file_creations")
        // callUDF("percentile_approx", col("num_failed_logins"), lit(0.5)).as("num_failed_logins_Median"),
         //callUDF("percentile_approx", col("num_compromised"), lit(0.5)).as("num_compromised_Median"),
         //callUDF("percentile_approx", col("num_file_creations"), lit(0.5)).as("num_file_creations_Median")
         )
      
         
         df_with_stdev.createOrReplaceTempView("DataFrame_with_Stdev")


     def median(inputList: List[Int]): Double = {
  val count = inputList.size
  if (count % 2 == 0) {
    val l = count / 2 - 1
    val r = l + 1
    (inputList(l) + inputList(r)).toDouble / 2
  } else
    inputList(count / 2).toDouble
}
     
  
  //Another way of Median calculation of num_failed_logins
  
   val failed_logins:RDD[(String,Int)]= spark.sql("select protocol_type,num_failed_logins from Network_Tracking").rdd.map(r=>(r(0).toString(),Integer.parseInt(r(1).toString())))
   val failed_logins_group_rdd = failed_logins.groupByKey()
   val failed_logins_sortedListRDD = failed_logins_group_rdd.mapValues(_.toList.sorted)  
     
 val failed_logins_median_df = failed_logins_sortedListRDD.map(m => {
  (m._1, median(m._2))
}).toDF("protocol_type", "median_of_num_failed_logins")
  

  failed_logins_median_df.createOrReplaceTempView("failed_logins_median_df")
 
 // Median calculation of num_compromised  
  
   val num_compromised:RDD[(String,Int)]= spark.sql("select protocol_type,num_compromised from Network_Tracking").rdd.map(r=>(r(0).toString(),Integer.parseInt(r(1).toString())))
   val num_compromised_group_rdd = num_compromised.groupByKey()
   val num_compromised_sortedListRDD = num_compromised_group_rdd.mapValues(_.toList.sorted)  
   
 val num_compromised_median_df = num_compromised_sortedListRDD.map(m => {
  (m._1, median(m._2))
}).toDF("protocol_type", "median_of_num_compromised")
  

  
  num_compromised_median_df.createOrReplaceTempView("num_compromised_median_df")
  

  // Median calculation of num_file_creations  
  
   val num_file_creations:RDD[(String,Int)]= spark.sql("select protocol_type,num_file_creations from Network_Tracking").rdd.map(r=>(r(0).toString(),Integer.parseInt(r(1).toString())))
   val num_file_creations_group_rdd = num_file_creations.groupByKey()
   val num_file_creations_sortedListRDD = num_file_creations_group_rdd.mapValues(_.toList.sorted)  
   
 val num_file_creations_median_df = num_file_creations_sortedListRDD.map(m => {
  (m._1, median(m._2))
}).toDF("protocol_type", "median_of_num_file_creations")
  

  
  num_file_creations_median_df.createOrReplaceTempView("num_file_creations_median_df")
  val final_median_df = spark.sql("select a.*,b.median_of_num_failed_logins,c.median_of_num_compromised,d.median_of_num_file_creations from  DataFrame_with_Stdev a join failed_logins_median_df b on a.protocol_type=b.protocol_type join num_compromised_median_df c on b.protocol_type=c.protocol_type join num_file_creations_median_df d on c.protocol_type=d.protocol_type")
  final_median_df.write.option("header", "true").csv("C:/Users/Ramanjaneyulu.K/Desktop/Task1")
     
  
 
  //  Task (3) Bucketize all the continous variables into bins for guest and non-guest logins. Output should be bin-wise counts sorted by bins. 

   logger.info("Filtering the Guest login Records and Non Guest Records")
   
val guest_logins_df = spark.sql("select * from Network_Tracking where is_guest_login=1")
val non_guest_logins_df = spark.sql("select * from Network_Tracking where is_guest_login=0")
  

 //Bucketing the duration continous variable


 val serror_rate_bucketizer = new Bucketizer()
                         .setInputCol("serror_rate")
                         .setOutputCol("serror_rate_bin")
                         .setSplits(Array(0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0))
 
  val serror_rate_bins =serror_rate_bucketizer.transform(guest_logins_df)
  
  serror_rate_bins.createOrReplaceTempView("serror_rate_bins")
  
  val guest_Loign_Bins = spark.sql("select count(serror_rate) guest_login_serror_rate_cnt,serror_rate_bin  from serror_rate_bins group by serror_rate_bin order by serror_rate_bin")
  
  guest_Loign_Bins.show()
  
 // guest_Loign_Bins.write.option("header", "true").csv("C:/Users/Ramanjaneyulu.K/Desktop/Task3_Guest_Loign")
    
 
 logger.info("Bucketizing the non guest logins")
 
 val serror_rate_bins_Non_Guest =serror_rate_bucketizer.transform(non_guest_logins_df)
  serror_rate_bins.createOrReplaceTempView("serror_rate_bins_Non_Guest")
  
  val Non_guest_Loign_Bins = spark.sql("select count(serror_rate) non_guest_serror_rate_cnt,serror_rate_bin  from serror_rate_bins_Non_Guest group by serror_rate_bin order by serror_rate_bin")

 Non_guest_Loign_Bins.write.option("header", "true").csv("C:/Users/Ramanjaneyulu.K/Desktop/Task3__Non_Guest_Loign")
 
 
         
  
  }    
}